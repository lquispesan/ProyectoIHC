from django.contrib import admin
from .models import alumno
# Register your models here.
admin.site.register(alumno)
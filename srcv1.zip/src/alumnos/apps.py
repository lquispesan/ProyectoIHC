from django.apps import AppConfig


class AlumnosConfig(AppConfig):
    name = 'alumnos'
